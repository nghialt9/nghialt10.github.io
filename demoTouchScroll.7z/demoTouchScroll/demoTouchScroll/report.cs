﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace demoTouchScroll
{
    public partial class report : Form
    {
        private Button printPreview;
        private OpenFileDialog openFileDialog;
        private PrintDocument pd = new PrintDocument();
        private int count;

        /// <summary>
        /// 
        /// </summary>
        public report()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        private void InitializeComponent()
        {
            this.printPreview = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // printPreview
            // 
            this.printPreview.Location = new System.Drawing.Point(12, 12);
            this.printPreview.Name = "printPreview";
            this.printPreview.Size = new System.Drawing.Size(145, 39);
            this.printPreview.TabIndex = 0;
            this.printPreview.Text = "Print Preview";
            this.printPreview.Click += new System.EventHandler(this.printPreview_Click);
            // 
            // report
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.printPreview);
            this.Name = "report";
            this.ShowIcon = false;
            this.ResumeLayout(false);

        }

        //load file emf
        private void loadImage()
        {
            System.IO.Path.GetDirectoryName(Application.ExecutablePath);
            count = 0;
            openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\emf";
            openFileDialog.Filter = "*emf files(*.emf) | *.emf";
            openFileDialog.Multiselect = true;
            DialogResult dr = openFileDialog.ShowDialog();
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                //init and show
                TouchScroll ts = new TouchScroll();
                this.pd.PrintPage += OnPrintPageEvent;
                this.pd.QueryPageSettings += OnQueryPageSettingsEvent;
                try
                {
                    ts.Document = this.pd;
                    ts.ShowDialog();
                }
                finally
                {
                    //close and reset
                    if(ts != null)
                    {
                        ts.Document = null;
                        ts.Dispose();
                    }
                    this.pd.PrintPage -= OnPrintPageEvent;
                    this.pd.QueryPageSettings -= OnQueryPageSettingsEvent;
                }
                
            }
            
        }

        //Page Print Event
        private void OnPrintPageEvent(object o, PrintPageEventArgs e)
        {
            Graphics g = e.Graphics;

            // Print page
            e.HasMorePages = PrintReportPage(g);
        }

        //Setting Event
        private void OnQueryPageSettingsEvent(object o, QueryPageSettingsEventArgs e)
        {
            if(count > openFileDialog.FileNames.Length)
            {
                e.Cancel = true;
            }
        }

        /// <summary>
        /// Print a report on one page
        /// </summary>
        /// <param name="g"></param>
        /// <returns></returns>
        private bool PrintReportPage( Graphics g )
        {
            try
            {
                using (Metafile img = new Metafile(openFileDialog.FileNames[count]))
                {
                    GraphicsUnit unit = GraphicsUnit.Pixel;
                    RectangleF bound = img.GetBounds(ref unit);
                    float ix = bound.X;
                    float iy = bound.Y;
                    g.PageUnit = GraphicsUnit.Pixel;
                    g.DrawImage(img, ix, iy);
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex);
            }
            count++;
            return count < openFileDialog.FileNames.Length;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void printPreview_Click(object sender, EventArgs e)
        {
            this.loadImage();
        }
    }

    /// <summary>
    /// 
    /// </summary>
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new report());
        }
    }
}
