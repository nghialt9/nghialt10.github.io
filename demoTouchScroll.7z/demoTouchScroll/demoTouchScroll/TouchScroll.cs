﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Infragistics.Win.Printing;
using Infragistics.Win.Touch;

namespace demoTouchScroll
{
    class TouchScroll : UltraPrintPreviewDialog
    {
        //zoom
        private int countTouchStart = 0;
        private int initialDistance = 0;

        /// <summary>
        /// 
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();

            // 
            // TouchScroll
            // 
            this.Name = "TouchScroll";
            this.ShowIcon = false;
            this.ResumeLayout(false);
        }
        /// <summary>
        /// touch event started
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void printPreviewControl_GestureQueryStatus(object o, GestureQueryStatusEventArgs e)
        {
            e.Mode &= GestureModes.Zoom;
            this.PrintPreviewControl.ZoomGesture += this.printPreviewControl_ZoomGesture;
            this.PrintPreviewControl.GestureCompleted += this.printPreviewControl_GestureCompleted;
        }

        /// <summary>
        /// touch event finished
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void printPreviewControl_GestureCompleted(object o, GestureCompletedEventArgs e)
        {
            //reset zoom
            this.countTouchStart = 0;
            this.initialDistance = 0;
            this.PrintPreviewControl.ZoomGesture -= printPreviewControl_ZoomGesture;
        }

        /// <summary>
        /// touch event started
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void printPreviewThumbnail_GestureQueryStatus(object o, GestureQueryStatusEventArgs e)
        {
            e.Mode &= GestureModes.None;
        }

        /// <summary>
        /// Zoom event start
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void printPreviewControl_ZoomGesture(object o, ZoomGestureEventArgs e)
        {
            //check the method that runs for the first time in zoom operation
            if (countTouchStart == 0)
            {
                initialDistance = e.Distance;
            }

            //If the distance varies from the initial distance then zoom
            if (e.Distance != initialDistance)
            {
                //If (e.Distance - initialDistance) > 1 then zoomIn
                if ((e.Distance - initialDistance) > 1)
                {
                    this.PrintPreviewControl.Settings.Zoom += 0.05;
                    if (this.PrintPreviewControl.CurrentZoom > 16)
                    {
                        this.PrintPreviewControl.Settings.Zoom = 16;
                    }
                }

                //If (e.Distance - initialDistance) < -1 then zoomOut
                if ((e.Distance - initialDistance) < -1)
                {
                    this.PrintPreviewControl.Settings.Zoom -= 0.05;
                    if (this.PrintPreviewControl.CurrentZoom < 0.0833)
                    {
                        this.PrintPreviewControl.Settings.Zoom = 0.0833;
                    }
                }
            }
            initialDistance = e.Distance;
            countTouchStart++;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.PrintPreviewControl.GestureQueryStatus += this.printPreviewControl_GestureQueryStatus;
            this.PrintPreviewThumbnail.GestureQueryStatus += this.printPreviewThumbnail_GestureQueryStatus;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            this.WindowState = FormWindowState.Maximized;
            this.Activate();
        }

    }
}
